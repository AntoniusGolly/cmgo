#' Raw input demo data set to run the full stack of cmgo functions.
#' Contains a list with sublists $par and $data.
"demo"
