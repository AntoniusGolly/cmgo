#' Half processed demo data set to run test centerline processing of cmgo. The data set already contains a centerline.
#' Contains a list with sublists $par and $data.
"demo1"
