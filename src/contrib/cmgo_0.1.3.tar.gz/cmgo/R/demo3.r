#' Fully processed demo data set to run test the output and plotting functions of cmgo.
#' In contrast to demo data set 2 this data set uses the reference centerline mode.
#' Contains a list with sublists $par and $data.
"demo3"
