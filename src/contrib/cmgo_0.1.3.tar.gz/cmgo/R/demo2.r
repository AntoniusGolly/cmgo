#' Fully processed demo data set to run test the output and plotting functions of cmgo.
#' Contains a list with sublists $par and $data.
"demo2"
